namespace AstraCraft.Models;

public sealed class AppConfig
{
    public string MinecraftDir { get; set; } = DefaultMinecraftDir();
    public string JavaPath { get; set; } = "";
    public string Nickname { get; set; } = "Player";
    public int RamGb { get; set; } = 4;
    public string SelectedVersion { get; set; } = "latest-release";
    public string Language { get; set; } = "ru";
    public bool AutoInstallBeforeLaunch { get; set; } = true;
    public bool AutoDownloadDependencies { get; set; } = true;
    public bool ShowHitboxesOnLaunch { get; set; } = false;
    public bool EnableXrayResourcePack { get; set; } = false;
    public string XrayPackFileName { get; set; } = "";
    public int PlayerMaxHealth { get; set; } = 20;
    public int PlayerArmor { get; set; } = 0;
    public int PlayerArmorToughness { get; set; } = 0;
    public string LastStarterSeed { get; set; } = "";

    public static string DefaultMinecraftDir()
    {
        if (OperatingSystem.IsWindows())
        {
            var appData = Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData);
            return Path.Combine(appData, ".minecraft");
        }
        if (OperatingSystem.IsMacOS())
        {
            return Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.Personal), "Library", "Application Support", "minecraft");
        }
        return Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.Personal), ".minecraft");
    }
}
