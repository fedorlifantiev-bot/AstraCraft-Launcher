namespace AstraCraft.Models;

public sealed record MinecraftVersion(string Id, string Type, string Url, DateTimeOffset ReleaseTime)
{
    public string DisplayType => Type switch
    {
        "release" => "Release",
        "snapshot" => "Snapshot",
        "old_beta" => "Beta",
        "old_alpha" => "Alpha",
        _ => Type
    };
}
