namespace AstraCraft.Models;

public sealed record FileItem(string Name, string Path, long SizeBytes, DateTime Modified)
{
    public string SizeText
    {
        get
        {
            double size = SizeBytes;
            string[] units = ["B", "KB", "MB", "GB"];
            var i = 0;
            while (size >= 1024 && i < units.Length - 1) { size /= 1024; i++; }
            return $"{size:0.#} {units[i]}";
        }
    }
}
