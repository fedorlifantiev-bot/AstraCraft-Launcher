param(
  [string]$InstallDir = $PSScriptRoot,
  [switch]$SkipJava
)

$ErrorActionPreference = 'Stop'
$ProgressPreference = 'SilentlyContinue'

function Write-Step($message) {
  Write-Host "[AstraCraft deps] $message"
}

function Find-JavaIn($root) {
  if (-not (Test-Path $root)) { return $null }
  $javaw = Get-ChildItem -Path $root -Recurse -Filter javaw.exe -ErrorAction SilentlyContinue | Select-Object -First 1
  if ($javaw) { return $javaw.FullName }
  $java = Get-ChildItem -Path $root -Recurse -Filter java.exe -ErrorAction SilentlyContinue | Select-Object -First 1
  if ($java) { return $java.FullName }
  return $null
}

if (-not $SkipJava) {
  $runtimeRoot = Join-Path $InstallDir 'Runtime\Java'
  $existing = Find-JavaIn $runtimeRoot
  if ($existing) {
    Write-Step "Java already exists: $existing"
  } else {
    Write-Step 'Downloading Eclipse Temurin 21 JRE for Windows x64...'
    New-Item -ItemType Directory -Force -Path $runtimeRoot | Out-Null
    $temp = Join-Path $env:TEMP 'astracraft-temurin-21-jre.zip'
    $url = 'https://api.adoptium.net/v3/binary/latest/21/ga/windows/x64/jre/hotspot/normal/eclipse'
    Invoke-WebRequest -Uri $url -OutFile $temp -UseBasicParsing

    $stage = Join-Path $env:TEMP ('astracraft-jre-' + [Guid]::NewGuid().ToString('N'))
    New-Item -ItemType Directory -Force -Path $stage | Out-Null
    Expand-Archive -Path $temp -DestinationPath $stage -Force

    $java = Find-JavaIn $stage
    if (-not $java) { throw 'Downloaded archive does not contain java.exe/javaw.exe.' }
    $binDir = Split-Path $java -Parent
    $root = Split-Path $binDir -Parent
    Copy-Item -Path (Join-Path $root '*') -Destination $runtimeRoot -Recurse -Force
    Remove-Item $stage -Recurse -Force -ErrorAction SilentlyContinue
    Remove-Item $temp -Force -ErrorAction SilentlyContinue
    Write-Step "Java installed to $runtimeRoot"
  }
}

Write-Step 'Dependencies are ready.'
