#define MyAppName "AstraCraft Launcher"
#define MyAppVersion "3.4.0"
#define MyAppPublisher "AstraCraft"
#define MyAppExeName "AstraCraftLauncher.exe"

[Setup]
AppId={{8A3A3F59-8F2C-4CC1-93BA-AC4B06257B40}
AppName={#MyAppName}
AppVersion={#MyAppVersion}
AppPublisher={#MyAppPublisher}
DefaultDirName={localappdata}\AstraCraftLauncher
DefaultGroupName=AstraCraft Launcher
DisableProgramGroupPage=no
OutputDir=..\dist
OutputBaseFilename=AstraCraftLauncherSetup-x64
Compression=lzma2
SolidCompression=yes
WizardStyle=modern
PrivilegesRequired=lowest
SetupIconFile=..\Installer\MSIX\Assets\Square44x44Logo.ico
UninstallDisplayIcon={app}\{#MyAppExeName}
ArchitecturesAllowed=x64compatible
MinVersion=10.0

[Languages]
Name: "russian"; MessagesFile: "compiler:Languages\Russian.isl"
Name: "english"; MessagesFile: "compiler:Default.isl"

[Tasks]
Name: "desktopicon"; Description: "Создать ярлык на рабочем столе"; GroupDescription: "Ярлыки:"; Flags: checkedonce
Name: "startmenu"; Description: "Создать ярлык в меню Пуск"; GroupDescription: "Ярлыки:"; Flags: checkedonce
Name: "downloadjava"; Description: "Автоматически скачать portable Java 21 JRE после установки"; GroupDescription: "Зависимости:"; Flags: checkedonce unchecked
Name: "launchapp"; Description: "Запустить AstraCraft Launcher после установки"; GroupDescription: "После установки:"; Flags: checkedonce

[Files]
Source: "..\dist\AstraCraftLauncher\*"; DestDir: "{app}"; Flags: ignoreversion recursesubdirs createallsubdirs

[Icons]
Name: "{autoprograms}\AstraCraft Launcher"; Filename: "{app}\{#MyAppExeName}"; Tasks: startmenu
Name: "{autodesktop}\AstraCraft Launcher"; Filename: "{app}\{#MyAppExeName}"; Tasks: desktopicon

[Run]
Filename: "powershell.exe"; Parameters: "-NoProfile -ExecutionPolicy Bypass -File ""{app}\Install-AstraCraftDependencies.ps1"" -InstallDir ""{app}"""; StatusMsg: "Скачивание зависимостей AstraCraft..."; Flags: runhidden waituntilterminated; Tasks: downloadjava
Filename: "{app}\{#MyAppExeName}"; Description: "Запустить AstraCraft Launcher"; Flags: nowait postinstall skipifsilent; Tasks: launchapp

[UninstallDelete]
Type: files; Name: "{app}\astracraft_dependency_cache.reserve.bin"
