using System.Net;
using System.Net.Http;
using System.Text.Json;
using System.Text.Json.Serialization;
using System.Text.RegularExpressions;
using System.Xml.Linq;

namespace AstraCraft.Services;

public sealed record ModrinthProject(
    string Title,
    string Slug,
    string ProjectType,
    string Description,
    string Author,
    int Downloads,
    int Follows,
    IReadOnlyList<string> Versions,
    IReadOnlyList<string> Categories);

public sealed record ModrinthNewsItem(string Title, string Link, string Summary, DateTimeOffset? Published);

public sealed class ModrinthService
{
    private const string ApiBase = "https://api.modrinth.com/v3";
    private const string NewsFeed = "https://modrinth.com/news/feed/rss.xml";

    private static readonly JsonSerializerOptions JsonOptions = new(JsonSerializerDefaults.Web)
    {
        PropertyNameCaseInsensitive = true
    };

    private static readonly HttpClient Http = CreateClient();

    public async Task<IReadOnlyList<ModrinthProject>> SearchAsync(string projectType, string? query, int limit = 30)
    {
        projectType = NormalizeProjectType(projectType);
        limit = Math.Clamp(limit, 1, 100);

        var facets = Uri.EscapeDataString($"[[\"project_type:{projectType}\"]]");
        var url = $"{ApiBase}/search?limit={limit}&offset=0&index=relevance&facets={facets}";
        if (!string.IsNullOrWhiteSpace(query)) url += "&query=" + Uri.EscapeDataString(query.Trim());

        using var response = await Http.GetAsync(url);
        response.EnsureSuccessStatusCode();
        await using var stream = await response.Content.ReadAsStreamAsync();
        var payload = await JsonSerializer.DeserializeAsync<ModrinthSearchResponse>(stream, JsonOptions);

        return payload?.Hits?.Select(hit => new ModrinthProject(
            hit.Title ?? hit.Slug ?? "Untitled",
            hit.Slug ?? hit.ProjectId ?? "",
            NormalizeProjectType(hit.ProjectType),
            hit.Description ?? "",
            hit.Author ?? "",
            hit.Downloads,
            hit.Follows,
            ReadOnly(hit.Versions),
            ReadOnly(hit.Categories))).ToList() ?? new List<ModrinthProject>();
    }

    public async Task<IReadOnlyList<ModrinthNewsItem>> NewsAsync(int limit = 12)
    {
        limit = Math.Clamp(limit, 1, 30);
        var xml = await Http.GetStringAsync(NewsFeed);
        var doc = XDocument.Parse(xml);
        return doc.Descendants("item")
            .Take(limit)
            .Select(item => new ModrinthNewsItem(
                (string?)item.Element("title") ?? "News",
                (string?)item.Element("link") ?? "https://modrinth.com/news",
                CleanText((string?)item.Element("description") ?? ""),
                TryParseDate((string?)item.Element("pubDate"))))
            .ToList();
    }

    public static string ProjectUrlOnBlack(string projectType, string slug)
    {
        var route = NormalizeProjectType(projectType) switch
        {
            "mod" => "mod",
            "shader" => "shader",
            "modpack" => "modpack",
            "resourcepack" => "resourcepack",
            "datapack" => "datapack",
            "plugin" => "plugin",
            _ => "mod"
        };
        return $"https://modrinth.black/{route}/{Uri.EscapeDataString(slug)}";
    }

    private static IReadOnlyList<string> ReadOnly(List<string>? values)
    {
        if (values is { Count: > 0 }) return values;
        return Array.Empty<string>();
    }

    private static HttpClient CreateClient()
    {
        var client = new HttpClient { Timeout = TimeSpan.FromSeconds(25) };
        client.DefaultRequestHeaders.UserAgent.TryParseAdd("AstraCraftLauncher/3.2");
        client.DefaultRequestHeaders.Accept.TryParseAdd("application/json");
        return client;
    }

    private static string NormalizeProjectType(string? type)
    {
        return (type ?? "mod").Trim().ToLowerInvariant() switch
        {
            "mods" => "mod",
            "mod" => "mod",
            "shaderpacks" => "shader",
            "shaders" => "shader",
            "shader" => "shader",
            "modpacks" => "modpack",
            "modpack" => "modpack",
            "resourcepacks" => "resourcepack",
            "resource_packs" => "resourcepack",
            "resourcepack" => "resourcepack",
            "datapacks" => "datapack",
            "datapack" => "datapack",
            "plugins" => "plugin",
            "plugin" => "plugin",
            _ => "mod"
        };
    }

    private static string CleanText(string html)
    {
        var text = Regex.Replace(html, "<.*?>", " ");
        text = WebUtility.HtmlDecode(text);
        text = Regex.Replace(text, @"\s+", " ").Trim();
        return text.Length > 220 ? text[..220] + "..." : text;
    }

    private static DateTimeOffset? TryParseDate(string? raw)
    {
        return DateTimeOffset.TryParse(raw, out var parsed) ? parsed : null;
    }

    private sealed class ModrinthSearchResponse
    {
        [JsonPropertyName("hits")]
        public List<ModrinthHit>? Hits { get; set; }
    }

    private sealed class ModrinthHit
    {
        [JsonPropertyName("project_id")]
        public string? ProjectId { get; set; }

        [JsonPropertyName("slug")]
        public string? Slug { get; set; }

        [JsonPropertyName("title")]
        public string? Title { get; set; }

        [JsonPropertyName("description")]
        public string? Description { get; set; }

        [JsonPropertyName("project_type")]
        public string? ProjectType { get; set; }

        [JsonPropertyName("author")]
        public string? Author { get; set; }

        [JsonPropertyName("downloads")]
        public int Downloads { get; set; }

        [JsonPropertyName("follows")]
        public int Follows { get; set; }

        [JsonPropertyName("versions")]
        public List<string>? Versions { get; set; }

        [JsonPropertyName("categories")]
        public List<string>? Categories { get; set; }
    }
}
