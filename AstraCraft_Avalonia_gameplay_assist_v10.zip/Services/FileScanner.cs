using AstraCraft.Models;

namespace AstraCraft.Services;

public sealed class FileScanner
{
    public IReadOnlyList<FileItem> Scan(string minecraftDir, string category)
    {
        var dir = Path.Combine(minecraftDir, category);
        Directory.CreateDirectory(dir);
        return Directory.EnumerateFileSystemEntries(dir)
            .Select(p =>
            {
                var info = new FileInfo(p);
                long size = info.Exists ? info.Length : Directory.Exists(p) ? DirectorySize(p) : 0;
                var modified = info.Exists ? info.LastWriteTime : Directory.GetLastWriteTime(p);
                return new FileItem(Path.GetFileName(p), p, size, modified);
            })
            .OrderByDescending(x => x.Modified)
            .ToList();
    }

    public void Delete(string path)
    {
        if (!File.Exists(path) && !Directory.Exists(path)) return;

        var parent = Path.GetDirectoryName(path) ?? Environment.GetFolderPath(Environment.SpecialFolder.DesktopDirectory);
        var minecraftDir = Directory.GetParent(parent)?.FullName ?? parent;
        var trash = Path.Combine(minecraftDir, ".astracraft-trash", DateTime.Now.ToString("yyyyMMdd-HHmmss"));
        Directory.CreateDirectory(trash);

        var name = Path.GetFileName(path);
        var target = Path.Combine(trash, name);
        var index = 1;
        while (File.Exists(target) || Directory.Exists(target))
        {
            target = Path.Combine(trash, $"{Path.GetFileNameWithoutExtension(name)}-{index}{Path.GetExtension(name)}");
            index++;
        }

        if (File.Exists(path)) File.Move(path, target);
        else Directory.Move(path, target);
    }

    public void CopyInto(string minecraftDir, string category, IEnumerable<string> sourcePaths)
    {
        var targetDir = Path.Combine(minecraftDir, category);
        Directory.CreateDirectory(targetDir);
        foreach (var src in sourcePaths)
        {
            if (!File.Exists(src)) continue;
            var target = Path.Combine(targetDir, Path.GetFileName(src));
            File.Copy(src, target, true);
        }
    }

    private static long DirectorySize(string path)
    {
        try { return Directory.EnumerateFiles(path, "*", SearchOption.AllDirectories).Sum(f => new FileInfo(f).Length); }
        catch { return 0; }
    }
}
