using System.IO.Compression;

namespace AstraCraft.Services;

public sealed class DependencyService
{
    private const string Temurin21JreZipUrl = "https://api.adoptium.net/v3/binary/latest/21/ga/windows/x64/jre/hotspot/normal/eclipse";

    private readonly JavaService _java;
    private readonly string _baseDir;
    private readonly string _dependenciesDir;
    private readonly string _javaDir;
    private readonly string _downloadsDir;

    public DependencyService(JavaService java, ConfigService config)
    {
        _java = java;
        _baseDir = AppContext.BaseDirectory;
        _dependenciesDir = Path.Combine(config.ConfigDir, "Dependencies");
        _javaDir = Path.Combine(_dependenciesDir, "Java");
        _downloadsDir = Path.Combine(_dependenciesDir, "Downloads");
    }

    public string? FindUsableJava(string? configured, bool preferJavaw)
    {
        try { return _java.FindJava(preferJavaw, configured); }
        catch { return null; }
    }

    public async Task<string> EnsureJavaAsync(string? configured, bool autoDownload, IProgress<string>? progress = null, CancellationToken token = default)
    {
        var existing = FindUsableJava(configured, preferJavaw: true);
        if (!string.IsNullOrWhiteSpace(existing)) return existing;

        if (!OperatingSystem.IsWindows())
        {
            throw new FileNotFoundException("Java not found. Install Java 17+ or set Java path in Settings.");
        }

        if (!autoDownload)
        {
            throw new FileNotFoundException("Java not found and automatic dependency download is disabled in Settings.");
        }

        progress?.Report("Java not found. Downloading Eclipse Temurin 21 JRE...");
        Directory.CreateDirectory(_javaDir);
        Directory.CreateDirectory(_downloadsDir);

        var zipPath = Path.Combine(_downloadsDir, "temurin-21-jre-windows-x64.zip");
        if (!File.Exists(zipPath) || new FileInfo(zipPath).Length < 50_000_000)
        {
            using var http = new HttpClient();
            http.DefaultRequestHeaders.UserAgent.ParseAdd("AstraCraftLauncher/3.4");
            using var response = await http.GetAsync(Temurin21JreZipUrl, HttpCompletionOption.ResponseHeadersRead, token);
            response.EnsureSuccessStatusCode();
            await using var input = await response.Content.ReadAsStreamAsync(token);
            await using var output = File.Create(zipPath);
            await input.CopyToAsync(output, token);
        }

        progress?.Report("Extracting Java runtime...");
        var staging = Path.Combine(_javaDir, "_staging");
        if (Directory.Exists(staging)) Directory.Delete(staging, recursive: true);
        Directory.CreateDirectory(staging);
        ZipFile.ExtractToDirectory(zipPath, staging, overwriteFiles: true);

        var javaw = Directory.EnumerateFiles(staging, "javaw.exe", SearchOption.AllDirectories).FirstOrDefault()
                    ?? Directory.EnumerateFiles(staging, "java.exe", SearchOption.AllDirectories).FirstOrDefault();
        if (javaw == null) throw new FileNotFoundException("Downloaded Java archive did not contain java.exe/javaw.exe.");

        var extractedRoot = FindRuntimeRoot(javaw, staging);
        var finalDir = Path.Combine(_javaDir, "temurin-21-jre");
        if (Directory.Exists(finalDir)) Directory.Delete(finalDir, recursive: true);
        Directory.Move(extractedRoot, finalDir);
        if (Directory.Exists(staging)) Directory.Delete(staging, recursive: true);

        var result = Directory.EnumerateFiles(finalDir, "javaw.exe", SearchOption.AllDirectories).FirstOrDefault()
                     ?? Directory.EnumerateFiles(finalDir, "java.exe", SearchOption.AllDirectories).First();
        progress?.Report("Java runtime ready: " + result);
        return result;
    }

    private static string FindRuntimeRoot(string javaExePath, string stagingRoot)
    {
        var dir = new DirectoryInfo(Path.GetDirectoryName(javaExePath)!);
        while (dir.Parent != null && !string.Equals(dir.Name, "bin", StringComparison.OrdinalIgnoreCase)) dir = dir.Parent;
        if (string.Equals(dir.Name, "bin", StringComparison.OrdinalIgnoreCase) && dir.Parent != null) return dir.Parent.FullName;
        return stagingRoot;
    }
}
