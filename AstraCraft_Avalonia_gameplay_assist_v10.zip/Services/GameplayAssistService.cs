using System.Text;
using System.Text.Json;

namespace AstraCraft.Services;

public sealed record StarterSeed(string Title, string Seed, string Note);

public sealed class GameplayAssistService
{
    private static readonly string[] Themes =
    {
        "Village start",
        "Builder plains",
        "Forest survival",
        "Cave explorer",
        "Mountain base",
        "River valley",
        "Cozy island",
        "Cherry adventure",
        "Desert trader",
        "Taiga cabin"
    };

    private static readonly string[] Notes =
    {
        "Good when you want a calm first base and easy early resources.",
        "Try this for a simple survival start with room for farms and builds.",
        "A starter-friendly seed candidate. Terrain still depends on the selected Minecraft version.",
        "Use this when you want to test a world before committing to a long survival save.",
        "Balanced candidate for a new single-player world. Check spawn before making it your main world."
    };

    public StarterSeed GenerateStarterSeed(string? versionId)
    {
        var theme = Themes[Random.Shared.Next(Themes.Length)];
        var note = Notes[Random.Shared.Next(Notes.Length)];
        var seed = BitConverter.ToInt64(Guid.NewGuid().ToByteArray(), 0);
        var version = string.IsNullOrWhiteSpace(versionId) ? "selected version" : versionId.Trim();
        return new StarterSeed(theme, seed.ToString(), note + " Version: " + version + ".");
    }

    public string SaveSeedToLauncherFolder(string minecraftDir, StarterSeed seed)
    {
        var dir = Path.Combine(minecraftDir, "AstraCraft", "Seeds");
        Directory.CreateDirectory(dir);
        var path = Path.Combine(dir, "starter-seeds.txt");
        var line = $"{DateTime.Now:yyyy-MM-dd HH:mm:ss}\t{seed.Title}\t{seed.Seed}\t{seed.Note}{Environment.NewLine}";
        File.AppendAllText(path, line, Encoding.UTF8);
        return path;
    }

    public string WriteSingleplayerDatapack(string worldDir, int maxHealthPoints, int armorPoints, int armorToughness, IProgress<string>? progress = null)
    {
        if (string.IsNullOrWhiteSpace(worldDir)) throw new ArgumentException("World folder is empty.", nameof(worldDir));
        if (!Directory.Exists(worldDir)) throw new DirectoryNotFoundException(worldDir);

        maxHealthPoints = Math.Clamp(maxHealthPoints, 2, 80);
        armorPoints = Math.Clamp(armorPoints, 0, 30);
        armorToughness = Math.Clamp(armorToughness, 0, 20);

        var packDir = Path.Combine(worldDir, "datapacks", "AstraCraft_Player_Tuning");
        var functionOldDir = Path.Combine(packDir, "data", "astracraft", "functions");
        var functionNewDir = Path.Combine(packDir, "data", "astracraft", "function");
        var tagsOldDir = Path.Combine(packDir, "data", "minecraft", "tags", "functions");
        var tagsNewDir = Path.Combine(packDir, "data", "minecraft", "tags", "function");

        Directory.CreateDirectory(functionOldDir);
        Directory.CreateDirectory(functionNewDir);
        Directory.CreateDirectory(tagsOldDir);
        Directory.CreateDirectory(tagsNewDir);

        var packMeta = """
        {
          "pack": {
            "pack_format": 48,
            "supported_formats": {
              "min_inclusive": 15,
              "max_inclusive": 999
            },
            "description": "AstraCraft single-player health and armor tuning"
          }
        }
        """;
        File.WriteAllText(Path.Combine(packDir, "pack.mcmeta"), packMeta, Encoding.UTF8);

        var commands = BuildApplyFunction(maxHealthPoints, armorPoints, armorToughness);
        File.WriteAllText(Path.Combine(functionOldDir, "apply.mcfunction"), commands, Encoding.UTF8);
        File.WriteAllText(Path.Combine(functionNewDir, "apply.mcfunction"), commands, Encoding.UTF8);

        var tagJson = JsonSerializer.Serialize(new { values = new[] { "astracraft:apply" } }, new JsonSerializerOptions { WriteIndented = true });
        File.WriteAllText(Path.Combine(tagsOldDir, "load.json"), tagJson, Encoding.UTF8);
        File.WriteAllText(Path.Combine(tagsOldDir, "tick.json"), tagJson, Encoding.UTF8);
        File.WriteAllText(Path.Combine(tagsNewDir, "load.json"), tagJson, Encoding.UTF8);
        File.WriteAllText(Path.Combine(tagsNewDir, "tick.json"), tagJson, Encoding.UTF8);

        var readme = $"""
        AstraCraft Player Tuning
        ========================

        This datapack is intended only for single-player worlds or worlds where you have permission.
        It does not bypass multiplayer servers or anti-cheat systems.

        Applied values:
        - Max health: {maxHealthPoints} health points / {maxHealthPoints / 2.0:0.#} hearts
        - Armor: {armorPoints} points
        - Armor toughness: {armorToughness} points

        To remove it, delete this folder from the world's datapacks folder and run /reload in the world.
        """;
        File.WriteAllText(Path.Combine(packDir, "README_ASTRACRAFT.txt"), readme, Encoding.UTF8);

        progress?.Report("AstraCraft datapack created: " + packDir);
        return packDir;
    }

    private static string BuildApplyFunction(int maxHealthPoints, int armorPoints, int armorToughness)
    {
        return $"""
        # AstraCraft Player Tuning
        # Only for single-player worlds or worlds where you have permission.
        execute as @a run attribute @s minecraft:generic.max_health base set {maxHealthPoints}
        execute as @a run attribute @s minecraft:generic.armor base set {armorPoints}
        execute as @a run attribute @s minecraft:generic.armor_toughness base set {armorToughness}
        effect give @a minecraft:instant_health 1 10 true
        """;
    }
}
