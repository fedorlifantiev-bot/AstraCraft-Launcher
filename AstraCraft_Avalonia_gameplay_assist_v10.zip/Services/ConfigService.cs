using System.Text.Json;
using AstraCraft.Models;

namespace AstraCraft.Services;

public sealed class ConfigService
{
    public string ConfigDir { get; }
    public string ConfigPath { get; }

    public ConfigService()
    {
        ConfigDir = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "AstraCraftLauncher");
        Directory.CreateDirectory(ConfigDir);
        ConfigPath = Path.Combine(ConfigDir, "config.json");
    }

    public AppConfig Load()
    {
        try
        {
            if (File.Exists(ConfigPath))
            {
                var cfg = JsonSerializer.Deserialize<AppConfig>(File.ReadAllText(ConfigPath));
                if (cfg != null)
                {
                    if (string.IsNullOrWhiteSpace(cfg.Nickname)) cfg.Nickname = "Player";
                    if (cfg.RamGb < 1) cfg.RamGb = 4;
                    return cfg;
                }
            }
        }
        catch { }
        var fresh = new AppConfig();
        Save(fresh);
        return fresh;
    }

    public void Save(AppConfig config)
    {
        Directory.CreateDirectory(ConfigDir);
        File.WriteAllText(ConfigPath, JsonSerializer.Serialize(config, new JsonSerializerOptions { WriteIndented = true }));
    }
}
