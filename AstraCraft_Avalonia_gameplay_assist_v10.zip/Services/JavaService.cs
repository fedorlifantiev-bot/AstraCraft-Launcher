using System.Diagnostics;

namespace AstraCraft.Services;

public sealed class JavaService
{
    public string FindJava(bool preferJavaw, string? configured)
    {
        if (!string.IsNullOrWhiteSpace(configured) && File.Exists(configured)) return configured;
        var names = preferJavaw && OperatingSystem.IsWindows() ? new[] { "javaw.exe", "java.exe", "java" } : new[] { "java.exe", "javaw.exe", "java" };

        foreach (var root in LocalRuntimeRoots())
        {
            foreach (var n in names)
            {
                try
                {
                    var direct = Path.Combine(root, "bin", n);
                    if (File.Exists(direct)) return direct;
                    var recursive = Directory.Exists(root) ? Directory.EnumerateFiles(root, n, SearchOption.AllDirectories).FirstOrDefault() : null;
                    if (!string.IsNullOrWhiteSpace(recursive)) return recursive;
                }
                catch { }
            }
        }

        foreach (var n in names)
        {
            var found = Which(n);
            if (!string.IsNullOrWhiteSpace(found)) return found;
        }
        var javaHome = Environment.GetEnvironmentVariable("JAVA_HOME");
        if (!string.IsNullOrWhiteSpace(javaHome))
        {
            foreach (var n in names)
            {
                var p = Path.Combine(javaHome, "bin", n);
                if (File.Exists(p)) return p;
            }
        }
        throw new FileNotFoundException("Java not found. Install Java 17+ or set Java path in Settings.");
    }

    private static IEnumerable<string> LocalRuntimeRoots()
    {
        var app = AppContext.BaseDirectory;
        yield return Path.Combine(app, "Runtime", "Java");
        yield return Path.Combine(app, "Dependencies", "Java");
        yield return Path.Combine(app, "jre");
        yield return Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "AstraCraftLauncher", "Dependencies", "Java");
    }

    public static string? Which(string name)
    {
        var path = Environment.GetEnvironmentVariable("PATH") ?? "";
        foreach (var dir in path.Split(Path.PathSeparator, StringSplitOptions.RemoveEmptyEntries))
        {
            try
            {
                var p = Path.Combine(dir.Trim(), name);
                if (File.Exists(p)) return p;
            }
            catch { }
        }
        return null;
    }

    public async Task<string> VersionAsync(string javaPath)
    {
        var psi = new ProcessStartInfo
        {
            FileName = javaPath,
            Arguments = "-version",
            UseShellExecute = false,
            RedirectStandardError = true,
            RedirectStandardOutput = true,
            CreateNoWindow = true
        };
        using var p = Process.Start(psi);
        if (p == null) return "Unknown";
        var output = await p.StandardError.ReadToEndAsync();
        output += await p.StandardOutput.ReadToEndAsync();
        await p.WaitForExitAsync();
        return output.Split('\n', StringSplitOptions.RemoveEmptyEntries).FirstOrDefault()?.Trim() ?? "Unknown";
    }
}
