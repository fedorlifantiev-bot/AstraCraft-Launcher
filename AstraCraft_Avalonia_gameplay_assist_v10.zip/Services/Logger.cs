using System.Text;

namespace AstraCraft.Services;

public sealed class Logger
{
    private readonly object _lock = new();
    public event Action<string>? Line;
    public string LogDir { get; }

    public Logger()
    {
        var local = Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData);
        LogDir = Path.Combine(local, "AstraCraftLauncher", "logs");
        Directory.CreateDirectory(LogDir);
    }

    public string MainLogPath => Path.Combine(LogDir, "app.log");
    public string LaunchLogPath(string minecraftDir) => Path.Combine(minecraftDir, "logs", "astracraft-launch.log");

    public void Info(string message) => Write("INFO", message);
    public void Warn(string message) => Write("WARN", message);
    public void Error(string message, Exception? ex = null) => Write("ERROR", ex == null ? message : message + "\n" + ex);

    private void Write(string level, string message)
    {
        var line = $"[{DateTime.Now:yyyy-MM-dd HH:mm:ss}] [{level}] {message}";
        lock (_lock)
        {
            File.AppendAllText(MainLogPath, line + Environment.NewLine, Encoding.UTF8);
        }
        Line?.Invoke(line);
    }
}
