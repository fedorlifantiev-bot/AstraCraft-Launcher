using System.Diagnostics;
using System.IO.Compression;
using System.Net.Http;
using System.Runtime.InteropServices;
using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using System.Text.Json.Nodes;
using System.Text.RegularExpressions;
using AstraCraft.Models;

namespace AstraCraft.Services;

public sealed class MinecraftService
{
    private const string ManifestUrl = "https://piston-meta.mojang.com/mc/game/version_manifest_v2.json";
    private readonly HttpClient _http = new() { Timeout = TimeSpan.FromSeconds(90) };
    private readonly Logger _log;
    private readonly JavaService _java = new();

    public MinecraftService(Logger log)
    {
        _log = log;
        _http.DefaultRequestHeaders.UserAgent.ParseAdd("AstraCraftLauncher/3.0");
    }

    public IReadOnlyList<string> InstalledVersions(string minecraftDir)
    {
        var dir = Path.Combine(minecraftDir, "versions");
        Directory.CreateDirectory(dir);
        return Directory.EnumerateDirectories(dir)
            .Select(Path.GetFileName)
            .Where(x => !string.IsNullOrWhiteSpace(x) && File.Exists(Path.Combine(dir, x!, x! + ".json")))
            .Cast<string>()
            .OrderByDescending(x => File.GetLastWriteTime(Path.Combine(dir, x)))
            .ToList();
    }

    public async Task<IReadOnlyList<MinecraftVersion>> CatalogAsync(CancellationToken token = default)
    {
        try
        {
            var json = await _http.GetStringAsync(ManifestUrl, token);
            using var doc = JsonDocument.Parse(json);
            var list = new List<MinecraftVersion>();
            foreach (var v in doc.RootElement.GetProperty("versions").EnumerateArray().Take(120))
            {
                var id = v.GetProperty("id").GetString() ?? "";
                var type = v.GetProperty("type").GetString() ?? "release";
                var url = v.GetProperty("url").GetString() ?? "";
                DateTimeOffset.TryParse(v.GetProperty("releaseTime").GetString(), out var time);
                if (!string.IsNullOrWhiteSpace(id)) list.Add(new MinecraftVersion(id, type, url, time));
            }
            if (list.Count > 0) return list;
        }
        catch (Exception ex)
        {
            _log.Warn("Version catalog unavailable: " + ex.Message);
        }
        return FallbackVersions();
    }

    public async Task<string> ResolveVersionIdAsync(string id, string minecraftDir, CancellationToken token = default)
    {
        if (id != "latest-release" && id != "latest-snapshot") return id;
        try
        {
            var json = await _http.GetStringAsync(ManifestUrl, token);
            using var doc = JsonDocument.Parse(json);
            var latest = doc.RootElement.GetProperty("latest");
            return id == "latest-snapshot" ? latest.GetProperty("snapshot").GetString() ?? "latest-snapshot" : latest.GetProperty("release").GetString() ?? "latest-release";
        }
        catch
        {
            return InstalledVersions(minecraftDir).FirstOrDefault() ?? FallbackVersions().First().Id;
        }
    }

    public async Task InstallVanillaAsync(string versionId, string minecraftDir, IProgress<string>? progress = null, CancellationToken token = default)
    {
        MinecraftPaths.EnsureBaseFolders(minecraftDir);
        versionId = await ResolveVersionIdAsync(versionId, minecraftDir, token);
        progress?.Report("Preparing " + versionId);
        var versionJson = await EnsureVersionJsonAsync(versionId, minecraftDir, token);
        await using var mergedStream = await ReadMergedVersionJsonStreamAsync(versionJson, minecraftDir, token);
        using var merged = await JsonDocument.ParseAsync(mergedStream, cancellationToken: token);
        var jarId = JarVersionId(merged.RootElement, versionId);
        if (jarId != versionId) await EnsureVersionJsonAsync(jarId, minecraftDir, token);
        await EnsureClientAsync(merged.RootElement, jarId, minecraftDir, progress, token);
        await EnsureLibrariesAsync(merged.RootElement, minecraftDir, progress, token);
        await EnsureAssetsAsync(merged.RootElement, minecraftDir, progress, token);
        await ExtractNativesAsync(merged.RootElement, versionId, minecraftDir, progress, token);
        progress?.Report("Installed " + versionId);
    }

    public async Task LaunchAsync(string versionId, string minecraftDir, string nickname, int ramGb, string? configuredJava, bool showHitboxesOnLaunch = false, IProgress<string>? progress = null, CancellationToken token = default, bool enableXrayResourcePack = false, string? xrayPackFileName = null)
    {
        MinecraftPaths.EnsureBaseFolders(minecraftDir);
        versionId = await ResolveVersionIdAsync(versionId, minecraftDir, token);
        progress?.Report("Preparing launch: " + versionId);

        var versionJson = Path.Combine(minecraftDir, "versions", versionId, versionId + ".json");
        if (!File.Exists(versionJson))
        {
            progress?.Report("Version is not installed. Installing vanilla " + versionId + "...");
            await InstallVanillaAsync(versionId, minecraftDir, progress, token);
        }

        await using var mergedStream = await ReadMergedVersionJsonStreamAsync(versionJson, minecraftDir, token);
        using var merged = await JsonDocument.ParseAsync(mergedStream, cancellationToken: token);
        var jarId = JarVersionId(merged.RootElement, versionId);
        if (jarId != versionId) await EnsureVersionJsonAsync(jarId, minecraftDir, token);
        await EnsureClientAsync(merged.RootElement, jarId, minecraftDir, progress, token);
        await EnsureLibrariesAsync(merged.RootElement, minecraftDir, progress, token);
        await EnsureAssetsAsync(merged.RootElement, minecraftDir, progress, token);
        await ExtractNativesAsync(merged.RootElement, versionId, minecraftDir, progress, token);

        var java = _java.FindJava(true, configuredJava);
        var classpath = BuildClasspath(merged.RootElement, versionId, jarId, minecraftDir);
        if (string.IsNullOrWhiteSpace(classpath)) throw new InvalidOperationException("Classpath is empty. Libraries/client jar were not found.");
        var mainClass = merged.RootElement.TryGetProperty("mainClass", out var mc) ? mc.GetString() ?? "net.minecraft.client.main.Main" : "net.minecraft.client.main.Main";
        var natives = Path.Combine(minecraftDir, "versions", versionId, "natives");

        var map = BuildPlaceholderMap(merged.RootElement, versionId, minecraftDir, nickname, classpath, natives);
        var jvmArgs = BuildJvmArgs(merged.RootElement, map, natives, classpath, ramGb);
        var gameArgs = BuildGameArgs(merged.RootElement, map);

        ApplyXrayResourcePack(minecraftDir, xrayPackFileName, enableXrayResourcePack, progress);

        var logPath = Path.Combine(minecraftDir, "logs", "astracraft-launch.log");
        Directory.CreateDirectory(Path.GetDirectoryName(logPath)!);
        await File.AppendAllTextAsync(logPath, $"\n=== Launch {DateTime.Now:yyyy-MM-dd HH:mm:ss} {versionId} ===\n", token);

        var psi = new ProcessStartInfo
        {
            FileName = java,
            WorkingDirectory = minecraftDir,
            UseShellExecute = false,
            CreateNoWindow = true,
            RedirectStandardOutput = true,
            RedirectStandardError = true
        };
        foreach (var arg in jvmArgs) psi.ArgumentList.Add(arg);
        psi.ArgumentList.Add(mainClass);
        foreach (var arg in gameArgs) psi.ArgumentList.Add(arg);

        _log.Info("Starting Minecraft: " + versionId);
        var process = Process.Start(psi) ?? throw new InvalidOperationException("Java process was not started.");
        _ = Task.Run(async () => await PumpProcessOutputAsync(process, logPath));
        progress?.Report("Minecraft started. PID " + process.Id);
        if (showHitboxesOnLaunch)
        {
            _ = Task.Run(async () => await TryToggleHitboxesAfterLaunchAsync(process, progress, token), CancellationToken.None);
        }
    }

    private void ApplyXrayResourcePack(string minecraftDir, string? xrayPackFileName, bool enabled, IProgress<string>? progress)
    {
        if (string.IsNullOrWhiteSpace(xrayPackFileName)) return;

        try
        {
            var packsDir = Path.Combine(minecraftDir, "resourcepacks");
            Directory.CreateDirectory(packsDir);
            Directory.CreateDirectory(Path.Combine(minecraftDir, "logs"));
            var safeName = Path.GetFileName(xrayPackFileName);
            var packPath = Path.Combine(packsDir, safeName);
            if (!File.Exists(packPath))
            {
                progress?.Report("X-Ray helper: pack not found in resourcepacks: " + safeName);
                return;
            }

            SetResourcePackInOptions(minecraftDir, safeName, enabled);
            progress?.Report(enabled
                ? "X-Ray helper: resource pack enabled for this profile. Use only in singleplayer/own worlds."
                : "X-Ray helper: resource pack disabled for this profile.");
        }
        catch (Exception ex)
        {
            progress?.Report("X-Ray helper error: " + ex.Message);
        }
    }

    private static void SetResourcePackInOptions(string minecraftDir, string packFileName, bool enabled)
    {
        var optionsPath = Path.Combine(minecraftDir, "options.txt");
        var entry = "file/" + packFileName.Replace('\\', '/');
        var quotedEntry = QuoteOptionsEntry(entry);
        var lines = File.Exists(optionsPath)
            ? File.ReadAllLines(optionsPath, Encoding.UTF8).ToList()
            : new List<string>();

        var index = lines.FindIndex(line => line.StartsWith("resourcePacks:", StringComparison.Ordinal));
        if (index < 0)
        {
            if (enabled) lines.Add("resourcePacks:[\"vanilla\"," + quotedEntry + "]");
            File.WriteAllLines(optionsPath, lines, Encoding.UTF8);
            return;
        }

        var prefix = "resourcePacks:";
        var value = lines[index][prefix.Length..].Trim();
        if (string.IsNullOrWhiteSpace(value) || value == "[]") value = "[\"vanilla\"]";

        if (enabled)
        {
            if (!value.Contains(quotedEntry, StringComparison.Ordinal) && !value.Contains(entry, StringComparison.Ordinal))
            {
                value = value.EndsWith("]", StringComparison.Ordinal)
                    ? value.Insert(value.Length - 1, (value.Length > 2 ? "," : "") + quotedEntry)
                    : "[\"vanilla\"," + quotedEntry + "]";
            }
        }
        else
        {
            value = value.Replace("," + quotedEntry, "", StringComparison.Ordinal)
                         .Replace(quotedEntry + ",", "", StringComparison.Ordinal)
                         .Replace(quotedEntry, "", StringComparison.Ordinal);
            value = value.Replace("[,,", "[", StringComparison.Ordinal).Replace(",,", ",", StringComparison.Ordinal).Replace(",]", "]", StringComparison.Ordinal);
            if (value == "[]") value = "[\"vanilla\"]";
        }

        lines[index] = prefix + value;
        File.WriteAllLines(optionsPath, lines, Encoding.UTF8);
    }

    private static string QuoteOptionsEntry(string value)
    {
        return "\"" + value.Replace("\\", "\\\\", StringComparison.Ordinal).Replace("\"", "\\\"", StringComparison.Ordinal) + "\"";
    }

    private async Task TryToggleHitboxesAfterLaunchAsync(Process process, IProgress<string>? progress, CancellationToken token)
    {
        if (!OperatingSystem.IsWindows())
        {
            progress?.Report("Hitboxes helper: auto-toggle is Windows-only. Press F3+B in game.");
            return;
        }

        progress?.Report("Hitboxes helper: waiting for the Minecraft window, then sending F3+B.");
        try
        {
            await Task.Delay(TimeSpan.FromSeconds(10), token);
            var handle = IntPtr.Zero;
            for (var i = 0; i < 45 && handle == IntPtr.Zero && !process.HasExited; i++)
            {
                process.Refresh();
                handle = process.MainWindowHandle;
                if (handle == IntPtr.Zero) await Task.Delay(1000, token);
            }

            if (handle == IntPtr.Zero || process.HasExited)
            {
                progress?.Report("Hitboxes helper: Minecraft window was not found. Press F3+B manually.");
                return;
            }

            ShowWindow(handle, 5);
            SetForegroundWindow(handle);
            await Task.Delay(650, token);
            SendKeyChord(VK_F3, VK_B);
            progress?.Report("Hitboxes helper: F3+B sent. If nothing changed, click the game window and press F3+B manually.");
        }
        catch (OperationCanceledException)
        {
        }
        catch (Exception ex)
        {
            progress?.Report("Hitboxes helper failed: " + ex.Message + ". Press F3+B manually.");
        }
    }

    private static void SendKeyChord(ushort holdKey, ushort tapKey)
    {
        var inputs = new[]
        {
            KeyboardInput(holdKey, 0),
            KeyboardInput(tapKey, 0),
            KeyboardInput(tapKey, KEYEVENTF_KEYUP),
            KeyboardInput(holdKey, KEYEVENTF_KEYUP)
        };
        var sent = SendInput((uint)inputs.Length, inputs, Marshal.SizeOf<INPUT>());
        if (sent != inputs.Length) throw new InvalidOperationException("SendInput did not send all keys.");
    }

    private static INPUT KeyboardInput(ushort key, uint flags) => new()
    {
        type = INPUT_KEYBOARD,
        U = new InputUnion
        {
            ki = new KEYBDINPUT { wVk = key, wScan = 0, dwFlags = flags, time = 0, dwExtraInfo = UIntPtr.Zero }
        }
    };

    private const int INPUT_KEYBOARD = 1;
    private const uint KEYEVENTF_KEYUP = 0x0002;
    private const ushort VK_F3 = 0x72;
    private const ushort VK_B = 0x42;

    [DllImport("user32.dll", SetLastError = true)]
    private static extern uint SendInput(uint nInputs, INPUT[] pInputs, int cbSize);

    [DllImport("user32.dll")]
    private static extern bool SetForegroundWindow(IntPtr hWnd);

    [DllImport("user32.dll")]
    private static extern bool ShowWindow(IntPtr hWnd, int nCmdShow);

    [StructLayout(LayoutKind.Sequential)]
    private struct INPUT
    {
        public int type;
        public InputUnion U;
    }

    [StructLayout(LayoutKind.Explicit)]
    private struct InputUnion
    {
        [FieldOffset(0)] public KEYBDINPUT ki;
    }

    [StructLayout(LayoutKind.Sequential)]
    private struct KEYBDINPUT
    {
        public ushort wVk;
        public ushort wScan;
        public uint dwFlags;
        public uint time;
        public UIntPtr dwExtraInfo;
    }

    public async Task RunInstallerJarAsync(string jarPath, string minecraftDir, string mcVersion, string loader, string? configuredJava, IProgress<string>? progress = null, CancellationToken token = default)
    {
        if (!File.Exists(jarPath)) throw new FileNotFoundException("Installer jar not found", jarPath);
        var java = _java.FindJava(false, configuredJava);
        Directory.CreateDirectory(minecraftDir);
        var args = loader.ToLowerInvariant() switch
        {
            "fabric" => new[] { "-jar", jarPath, "client", "-dir", minecraftDir, "-mcversion", mcVersion, "-noprofile" },
            "quilt" => new[] { "-jar", jarPath, "install", "client", mcVersion, "--install-dir=" + minecraftDir },
            _ => new[] { "-jar", jarPath, "--installClient" }
        };
        var psi = new ProcessStartInfo { FileName = java, WorkingDirectory = minecraftDir, UseShellExecute = false, RedirectStandardOutput = true, RedirectStandardError = true, CreateNoWindow = true };
        foreach (var a in args) psi.ArgumentList.Add(a);
        var p = Process.Start(psi) ?? throw new InvalidOperationException("Installer was not started.");
        while (!p.StandardOutput.EndOfStream) progress?.Report(await p.StandardOutput.ReadLineAsync() ?? "");
        var err = await p.StandardError.ReadToEndAsync();
        await p.WaitForExitAsync(token);
        if (p.ExitCode != 0) throw new InvalidOperationException($"Installer failed ({p.ExitCode}): {err}");
        if (!string.IsNullOrWhiteSpace(err)) _log.Warn(err);
    }

    private async Task<string> EnsureVersionJsonAsync(string versionId, string minecraftDir, CancellationToken token)
    {
        var dir = Path.Combine(minecraftDir, "versions", versionId);
        Directory.CreateDirectory(dir);
        var local = Path.Combine(dir, versionId + ".json");
        if (File.Exists(local) && new FileInfo(local).Length > 20) return local;
        var manifest = await _http.GetStringAsync(ManifestUrl, token);
        using var doc = JsonDocument.Parse(manifest);
        string? url = null;
        foreach (var v in doc.RootElement.GetProperty("versions").EnumerateArray())
        {
            if ((v.GetProperty("id").GetString() ?? "") == versionId)
            {
                url = v.GetProperty("url").GetString();
                break;
            }
        }
        if (string.IsNullOrWhiteSpace(url)) throw new InvalidOperationException("Version not found in Mojang manifest: " + versionId);
        await DownloadAsync(url, local, expectedSize: null, expectedSha1: null, token);
        return local;
    }

    private async Task<MemoryStream> ReadMergedVersionJsonStreamAsync(string versionJsonPath, string minecraftDir, CancellationToken token)
    {
        var json = await File.ReadAllTextAsync(versionJsonPath, token);
        var node = JsonNode.Parse(json)?.AsObject() ?? throw new InvalidOperationException("Invalid version json: " + versionJsonPath);
        if (node.TryGetPropertyValue("inheritsFrom", out var inheritedNode))
        {
            var parentId = inheritedNode?.GetValue<string>();
            if (!string.IsNullOrWhiteSpace(parentId))
            {
                var parentPath = await EnsureVersionJsonAsync(parentId, minecraftDir, token);
                await using var parentStream = await ReadMergedVersionJsonStreamAsync(parentPath, minecraftDir, token);
                var parentJson = Encoding.UTF8.GetString(parentStream.ToArray());
                var parentNode = JsonNode.Parse(parentJson)?.AsObject() ?? new JsonObject();
                node = MergeVersionJson(parentNode, node);
            }
        }
        var bytes = Encoding.UTF8.GetBytes(node.ToJsonString(new JsonSerializerOptions { WriteIndented = false }));
        return new MemoryStream(bytes);
    }

    private static JsonObject MergeVersionJson(JsonObject parent, JsonObject child)
    {
        var result = new JsonObject();
        foreach (var kv in parent) result[kv.Key] = kv.Value?.DeepClone();
        foreach (var kv in child)
        {
            if (kv.Key is "libraries" or "arguments") continue;
            result[kv.Key] = kv.Value?.DeepClone();
        }

        var libs = new JsonArray();
        if (parent["libraries"] is JsonArray pl) foreach (var x in pl) libs.Add(x?.DeepClone());
        if (child["libraries"] is JsonArray cl) foreach (var x in cl) libs.Add(x?.DeepClone());
        result["libraries"] = libs;

        if (parent["arguments"] is JsonObject || child["arguments"] is JsonObject)
        {
            var args = new JsonObject();
            if (parent["arguments"] is JsonObject parentArgs)
            {
                foreach (var kv in parentArgs) args[kv.Key] = kv.Value?.DeepClone();
            }
            if (child["arguments"] is JsonObject childArgs)
            {
                foreach (var kv in childArgs)
                {
                    if (kv.Value is JsonArray childArr && args[kv.Key] is JsonArray parentArr)
                    {
                        var merged = new JsonArray();
                        foreach (var x in parentArr) merged.Add(x?.DeepClone());
                        foreach (var x in childArr) merged.Add(x?.DeepClone());
                        args[kv.Key] = merged;
                    }
                    else args[kv.Key] = kv.Value?.DeepClone();
                }
            }
            result["arguments"] = args;
        }
        return result;
    }

    private async Task EnsureClientAsync(JsonElement root, string jarId, string minecraftDir, IProgress<string>? progress, CancellationToken token)
    {
        var jar = Path.Combine(minecraftDir, "versions", jarId, jarId + ".jar");
        if (File.Exists(jar) && new FileInfo(jar).Length > 0) return;
        if (!root.TryGetProperty("downloads", out var d) || !d.TryGetProperty("client", out var c)) return;
        var url = c.TryGetProperty("url", out var u) ? u.GetString() : null;
        var size = c.TryGetProperty("size", out var s) ? s.GetInt64() : (long?)null;
        var sha1 = c.TryGetProperty("sha1", out var sh) ? sh.GetString() : null;
        if (!string.IsNullOrWhiteSpace(url))
        {
            progress?.Report("Downloading client jar " + jarId);
            await DownloadAsync(url, jar, size, sha1, token);
        }
    }

    private async Task EnsureLibrariesAsync(JsonElement root, string minecraftDir, IProgress<string>? progress, CancellationToken token)
    {
        if (!root.TryGetProperty("libraries", out var libs)) return;
        foreach (var lib in libs.EnumerateArray())
        {
            if (!IsAllowed(lib)) continue;
            LibraryArtifact? artifact = null;
            if (lib.TryGetProperty("downloads", out var dl) && dl.TryGetProperty("artifact", out var a)) artifact = ArtifactFromJson(a);
            artifact ??= ArtifactFromMavenName(lib);
            if (artifact == null) continue;
            var target = Path.Combine(minecraftDir, "libraries", artifact.Path.Replace('/', Path.DirectorySeparatorChar));
            if (IsValidFile(target, artifact.Size, artifact.Sha1)) continue;
            if (string.IsNullOrWhiteSpace(artifact.Url)) continue;
            progress?.Report("Downloading library " + Path.GetFileName(target));
            await DownloadAsync(artifact.Url, target, artifact.Size, artifact.Sha1, token);
        }
    }

    private async Task EnsureAssetsAsync(JsonElement root, string minecraftDir, IProgress<string>? progress, CancellationToken token)
    {
        if (!root.TryGetProperty("assetIndex", out var idx)) return;
        var id = idx.TryGetProperty("id", out var idEl) ? idEl.GetString() ?? "legacy" : "legacy";
        var url = idx.TryGetProperty("url", out var u) ? u.GetString() : null;
        if (string.IsNullOrWhiteSpace(url)) return;
        var indexPath = Path.Combine(minecraftDir, "assets", "indexes", id + ".json");
        var size = idx.TryGetProperty("size", out var s) ? s.GetInt64() : (long?)null;
        var sha1 = idx.TryGetProperty("sha1", out var sh) ? sh.GetString() : null;
        if (!IsValidFile(indexPath, size, sha1))
        {
            progress?.Report("Downloading asset index " + id);
            await DownloadAsync(url, indexPath, size, sha1, token);
        }
        using var doc = JsonDocument.Parse(await File.ReadAllTextAsync(indexPath, token));
        if (!doc.RootElement.TryGetProperty("objects", out var objects)) return;
        var count = 0;
        foreach (var obj in objects.EnumerateObject())
        {
            var hash = obj.Value.TryGetProperty("hash", out var h) ? h.GetString() : null;
            var objSize = obj.Value.TryGetProperty("size", out var os) ? os.GetInt64() : (long?)null;
            if (string.IsNullOrWhiteSpace(hash) || hash.Length < 2) continue;
            var sub = hash[..2];
            var dest = Path.Combine(minecraftDir, "assets", "objects", sub, hash);
            if (!IsValidFile(dest, objSize, hash))
            {
                if (++count % 30 == 0) progress?.Report("Downloading assets... " + count);
                await DownloadAsync($"https://resources.download.minecraft.net/{sub}/{hash}", dest, objSize, hash, token);
            }
        }
        await BuildLegacyAssetsIfNeededAsync(doc.RootElement, id, minecraftDir, token);
    }

    private async Task BuildLegacyAssetsIfNeededAsync(JsonElement assetIndex, string id, string minecraftDir, CancellationToken token)
    {
        var needsVirtual = assetIndex.TryGetProperty("virtual", out var v) && v.GetBoolean();
        var mapToResources = assetIndex.TryGetProperty("map_to_resources", out var m) && m.GetBoolean();
        if (!needsVirtual && !mapToResources) return;
        if (!assetIndex.TryGetProperty("objects", out var objects)) return;
        foreach (var obj in objects.EnumerateObject())
        {
            var hash = obj.Value.GetProperty("hash").GetString();
            if (string.IsNullOrWhiteSpace(hash) || hash.Length < 2) continue;
            var src = Path.Combine(minecraftDir, "assets", "objects", hash[..2], hash);
            if (!File.Exists(src)) continue;
            if (needsVirtual)
            {
                var dest = Path.Combine(minecraftDir, "assets", "virtual", id, obj.Name.Replace('/', Path.DirectorySeparatorChar));
                Directory.CreateDirectory(Path.GetDirectoryName(dest)!);
                if (!File.Exists(dest)) File.Copy(src, dest, true);
            }
            if (mapToResources)
            {
                var dest = Path.Combine(minecraftDir, "resources", obj.Name.Replace('/', Path.DirectorySeparatorChar));
                Directory.CreateDirectory(Path.GetDirectoryName(dest)!);
                if (!File.Exists(dest)) File.Copy(src, dest, true);
            }
            await Task.Yield();
            token.ThrowIfCancellationRequested();
        }
    }

    private async Task ExtractNativesAsync(JsonElement root, string versionId, string minecraftDir, IProgress<string>? progress, CancellationToken token)
    {
        if (!root.TryGetProperty("libraries", out var libs)) return;
        var nativesDir = Path.Combine(minecraftDir, "versions", versionId, "natives");
        Directory.CreateDirectory(nativesDir);
        foreach (var lib in libs.EnumerateArray())
        {
            if (!IsAllowed(lib)) continue;
            var native = NativeArtifact(lib);
            if (native == null) continue;
            var jar = Path.Combine(minecraftDir, "libraries", native.Path.Replace('/', Path.DirectorySeparatorChar));
            if (!IsValidFile(jar, native.Size, native.Sha1) && !string.IsNullOrWhiteSpace(native.Url))
            {
                progress?.Report("Downloading native " + Path.GetFileName(jar));
                await DownloadAsync(native.Url, jar, native.Size, native.Sha1, token);
            }
            if (!File.Exists(jar)) continue;
            progress?.Report("Extracting natives " + Path.GetFileName(jar));
            try
            {
                using var zip = ZipFile.OpenRead(jar);
                foreach (var e in zip.Entries)
                {
                    if (string.IsNullOrWhiteSpace(e.Name)) continue;
                    if (e.FullName.StartsWith("META-INF/", StringComparison.OrdinalIgnoreCase)) continue;
                    var dest = Path.Combine(nativesDir, e.Name);
                    e.ExtractToFile(dest, true);
                }
            }
            catch (Exception ex)
            {
                _log.Warn("Native extraction skipped: " + ex.Message);
            }
        }
    }

    private static string BuildClasspath(JsonElement root, string versionId, string jarId, string minecraftDir)
    {
        var items = new List<string>();
        if (root.TryGetProperty("libraries", out var libs))
        {
            foreach (var lib in libs.EnumerateArray())
            {
                if (!IsAllowed(lib)) continue;
                LibraryArtifact? artifact = null;
                if (lib.TryGetProperty("downloads", out var dl) && dl.TryGetProperty("artifact", out var a)) artifact = ArtifactFromJson(a);
                artifact ??= ArtifactFromMavenName(lib);
                if (artifact == null) continue;
                var path = Path.Combine(minecraftDir, "libraries", artifact.Path.Replace('/', Path.DirectorySeparatorChar));
                if (File.Exists(path)) items.Add(path);
            }
        }
        var client = Path.Combine(minecraftDir, "versions", jarId, jarId + ".jar");
        if (File.Exists(client)) items.Add(client);
        var selfJar = Path.Combine(minecraftDir, "versions", versionId, versionId + ".jar");
        if (versionId != jarId && File.Exists(selfJar)) items.Add(selfJar);
        return string.Join(Path.PathSeparator, items.Distinct(StringComparer.OrdinalIgnoreCase));
    }

    private static Dictionary<string, string> BuildPlaceholderMap(JsonElement root, string versionId, string minecraftDir, string nickname, string classpath, string natives)
    {
        var assets = root.TryGetProperty("assets", out var av) ? av.GetString() ?? "legacy" : "legacy";
        return new Dictionary<string, string>
        {
            ["${auth_player_name}"] = nickname,
            ["${version_name}"] = versionId,
            ["${game_directory}"] = minecraftDir,
            ["${assets_root}"] = Path.Combine(minecraftDir, "assets"),
            ["${assets_index_name}"] = assets,
            ["${auth_uuid}"] = OfflineUuid(nickname, false),
            ["${auth_access_token}"] = "0",
            ["${user_type}"] = "legacy",
            ["${version_type}"] = root.TryGetProperty("type", out var t) ? t.GetString() ?? "release" : "release",
            ["${natives_directory}"] = natives,
            ["${launcher_name}"] = "AstraCraftLauncher",
            ["${launcher_version}"] = "3.0.0",
            ["${classpath}"] = classpath,
            ["${classpath_separator}"] = Path.PathSeparator.ToString(),
            ["${user_properties}"] = "{}",
            ["${auth_session}"] = "0",
            ["${clientid}"] = "",
            ["${auth_xuid}"] = "0",
            ["${quickPlayPath}"] = "",
            ["${quickPlaySingleplayer}"] = "",
            ["${quickPlayMultiplayer}"] = "",
            ["${quickPlayRealms}"] = ""
        };
    }

    private static List<string> BuildJvmArgs(JsonElement root, Dictionary<string, string> map, string natives, string classpath, int ramGb)
    {
        var args = new List<string>
        {
            $"-Xmx{Math.Clamp(ramGb, 1, 32)}G",
            "-Xms512M",
            "-XX:+UnlockExperimentalVMOptions",
            "-XX:+UseG1GC",
            "-XX:G1NewSizePercent=20",
            "-XX:G1ReservePercent=20",
            "-XX:MaxGCPauseMillis=50"
        };
        var usedOfficialJvm = false;
        if (root.TryGetProperty("arguments", out var arguments) && arguments.TryGetProperty("jvm", out var jvm))
        {
            var parsed = ParseArgumentArray(jvm).Select(x => ReplaceAll(x, map)).Where(x => !string.IsNullOrWhiteSpace(x)).ToList();
            if (parsed.Count > 0)
            {
                args.AddRange(parsed.Where(x => !x.StartsWith("-Xmx", StringComparison.OrdinalIgnoreCase) && !x.StartsWith("-Xms", StringComparison.OrdinalIgnoreCase)));
                usedOfficialJvm = true;
            }
        }
        if (!usedOfficialJvm)
        {
            args.Add("-Djava.library.path=" + natives);
            args.Add("-Dminecraft.launcher.brand=AstraCraftLauncher");
            args.Add("-Dminecraft.launcher.version=3.0.0");
            args.Add("-cp");
            args.Add(classpath);
        }
        return args;
    }

    private static List<string> BuildGameArgs(JsonElement root, Dictionary<string, string> map)
    {
        var args = new List<string>();
        if (root.TryGetProperty("arguments", out var arguments) && arguments.TryGetProperty("game", out var game))
            args.AddRange(ParseArgumentArray(game));
        else if (root.TryGetProperty("minecraftArguments", out var legacy))
            args.AddRange((legacy.GetString() ?? "").Split(' ', StringSplitOptions.RemoveEmptyEntries));
        else
            args.AddRange(new[] { "--username", "${auth_player_name}", "--version", "${version_name}", "--gameDir", "${game_directory}", "--assetsDir", "${assets_root}", "--assetIndex", "${assets_index_name}", "--uuid", "${auth_uuid}", "--accessToken", "${auth_access_token}", "--userType", "${user_type}" });
        return args.Select(x => ReplaceAll(x, map)).Where(x => !string.IsNullOrWhiteSpace(x)).ToList();
    }

    private static List<string> ParseArgumentArray(JsonElement array)
    {
        var args = new List<string>();
        foreach (var element in array.EnumerateArray()) AddArgumentElement(args, element);
        return args;
    }

    private static void AddArgumentElement(List<string> args, JsonElement arg)
    {
        if (arg.ValueKind == JsonValueKind.String) { args.Add(arg.GetString() ?? ""); return; }
        if (arg.ValueKind != JsonValueKind.Object) return;
        if (arg.TryGetProperty("rules", out var rules) && !RulesAllow(rules)) return;
        if (!arg.TryGetProperty("value", out var value)) return;
        if (value.ValueKind == JsonValueKind.String) args.Add(value.GetString() ?? "");
        else if (value.ValueKind == JsonValueKind.Array)
        {
            foreach (var v in value.EnumerateArray()) if (v.ValueKind == JsonValueKind.String) args.Add(v.GetString() ?? "");
        }
    }

    private static bool IsAllowed(JsonElement lib) => !lib.TryGetProperty("rules", out var rules) || RulesAllow(rules);

    private static bool RulesAllow(JsonElement rules)
    {
        var ruleList = rules.EnumerateArray().ToList();
        var hasAllow = ruleList.Any(r => r.TryGetProperty("action", out var a) && a.GetString() == "allow");
        var allowed = !hasAllow;
        foreach (var rule in ruleList)
        {
            var action = rule.TryGetProperty("action", out var a) ? a.GetString() ?? "allow" : "allow";
            if (RuleMatches(rule)) allowed = action == "allow";
        }
        return allowed;
    }

    private static bool RuleMatches(JsonElement rule)
    {
        if (rule.TryGetProperty("os", out var os))
        {
            if (os.TryGetProperty("name", out var n) && !string.Equals(n.GetString(), OsName(), StringComparison.OrdinalIgnoreCase)) return false;
            if (os.TryGetProperty("arch", out var arch))
            {
                var want = arch.GetString() ?? "";
                var have = Environment.Is64BitOperatingSystem ? "x64" : "x86";
                if (!want.Contains(have, StringComparison.OrdinalIgnoreCase) && !(want == "x86" && !Environment.Is64BitOperatingSystem)) return false;
            }
            if (os.TryGetProperty("version", out var ver))
            {
                try { if (!Regex.IsMatch(Environment.OSVersion.VersionString, ver.GetString() ?? ".*")) return false; }
                catch { }
            }
        }
        if (rule.TryGetProperty("features", out var features))
        {
            foreach (var f in features.EnumerateObject())
            {
                var requested = f.Value.ValueKind == JsonValueKind.True;
                var actual = false;
                if (requested != actual) return false;
            }
        }
        return true;
    }

    private static string OsName()
    {
        if (OperatingSystem.IsWindows()) return "windows";
        if (OperatingSystem.IsMacOS()) return "osx";
        return "linux";
    }

    private static string JarVersionId(JsonElement root, string versionId)
    {
        if (root.TryGetProperty("jar", out var jar)) return jar.GetString() ?? versionId;
        if (root.TryGetProperty("inheritsFrom", out var inh)) return inh.GetString() ?? versionId;
        return versionId;
    }

    private static LibraryArtifact? NativeArtifact(JsonElement lib)
    {
        if (!lib.TryGetProperty("natives", out var natives)) return null;
        if (!natives.TryGetProperty(OsName(), out var key)) return null;
        var classifier = (key.GetString() ?? "").Replace("${arch}", Environment.Is64BitOperatingSystem ? "64" : "32");
        if (string.IsNullOrWhiteSpace(classifier)) return null;
        if (lib.TryGetProperty("downloads", out var d) && d.TryGetProperty("classifiers", out var classifiers) && classifiers.TryGetProperty(classifier, out var native)) return ArtifactFromJson(native);
        return ArtifactFromMavenName(lib, classifier);
    }

    private static LibraryArtifact? ArtifactFromJson(JsonElement artifact)
    {
        var path = artifact.TryGetProperty("path", out var p) ? p.GetString() : null;
        var url = artifact.TryGetProperty("url", out var u) ? u.GetString() : null;
        var size = artifact.TryGetProperty("size", out var s) ? s.GetInt64() : (long?)null;
        var sha1 = artifact.TryGetProperty("sha1", out var sh) ? sh.GetString() : null;
        return string.IsNullOrWhiteSpace(path) ? null : new LibraryArtifact(path, url ?? "", size, sha1);
    }

    private static LibraryArtifact? ArtifactFromMavenName(JsonElement lib, string? classifier = null)
    {
        if (!lib.TryGetProperty("name", out var n)) return null;
        var parts = (n.GetString() ?? "").Split(':');
        if (parts.Length < 3) return null;
        var group = parts[0].Replace('.', '/');
        var artifact = parts[1];
        var version = parts[2];
        var suffix = string.IsNullOrWhiteSpace(classifier) ? "" : "-" + classifier;
        var fileName = $"{artifact}-{version}{suffix}.jar";
        var path = $"{group}/{artifact}/{version}/{fileName}";
        var baseUrl = lib.TryGetProperty("url", out var url) ? url.GetString() ?? "https://libraries.minecraft.net/" : "https://libraries.minecraft.net/";
        if (!baseUrl.EndsWith('/')) baseUrl += "/";
        return new LibraryArtifact(path, baseUrl + path, null, null);
    }

    private static bool IsValidFile(string path, long? size, string? sha1)
    {
        if (!File.Exists(path)) return false;
        var info = new FileInfo(path);
        if (info.Length <= 0) return false;
        if (size.HasValue && info.Length != size.Value) return false;
        if (!string.IsNullOrWhiteSpace(sha1) && sha1.Length == 40)
        {
            try { return Sha1(path).Equals(sha1, StringComparison.OrdinalIgnoreCase); }
            catch { return false; }
        }
        return true;
    }

    private async Task DownloadAsync(string url, string file, long? expectedSize, string? expectedSha1, CancellationToken token)
    {
        Directory.CreateDirectory(Path.GetDirectoryName(file)!);
        for (var attempt = 1; attempt <= 3; attempt++)
        {
            var tmp = file + ".tmp";
            try
            {
                using var response = await _http.GetAsync(url, HttpCompletionOption.ResponseHeadersRead, token);
                response.EnsureSuccessStatusCode();
                await using var input = await response.Content.ReadAsStreamAsync(token);
                await using (var output = File.Create(tmp)) await input.CopyToAsync(output, token);
                if (expectedSize.HasValue && new FileInfo(tmp).Length != expectedSize.Value) throw new IOException("Size mismatch: " + file);
                if (!string.IsNullOrWhiteSpace(expectedSha1) && expectedSha1.Length == 40 && !Sha1(tmp).Equals(expectedSha1, StringComparison.OrdinalIgnoreCase)) throw new IOException("SHA1 mismatch: " + file);
                if (File.Exists(file)) File.Delete(file);
                File.Move(tmp, file);
                return;
            }
            catch when (attempt < 3)
            {
                try { if (File.Exists(tmp)) File.Delete(tmp); } catch { }
                await Task.Delay(750 * attempt, token);
            }
        }
    }

    private static string Sha1(string path)
    {
        using var sha = SHA1.Create();
        using var fs = File.OpenRead(path);
        return Convert.ToHexString(sha.ComputeHash(fs)).ToLowerInvariant();
    }

    private static async Task PumpProcessOutputAsync(Process p, string logFile)
    {
        await using var fs = new FileStream(logFile, FileMode.Append, FileAccess.Write, FileShare.ReadWrite);
        await using var writer = new StreamWriter(fs, Encoding.UTF8) { AutoFlush = true };
        async Task Pump(StreamReader reader)
        {
            while (!reader.EndOfStream)
            {
                var line = await reader.ReadLineAsync();
                if (line != null) await writer.WriteLineAsync(line);
            }
        }
        await Task.WhenAll(Pump(p.StandardOutput), Pump(p.StandardError));
    }

    public static string OfflineUuid(string nickname, bool dashed = true)
    {
        var ns = new Guid("6ba7b811-9dad-11d1-80b4-00c04fd430c8").ToByteArray();
        SwapGuidBytesToNetwork(ns);
        var name = Encoding.UTF8.GetBytes("OfflinePlayer:" + nickname);
        var bytes = MD5.HashData(ns.Concat(name).ToArray());
        bytes[6] = (byte)((bytes[6] & 0x0f) | 0x30);
        bytes[8] = (byte)((bytes[8] & 0x3f) | 0x80);
        SwapGuidBytesFromNetwork(bytes);
        var guid = new Guid(bytes);
        return dashed ? guid.ToString() : guid.ToString("N");
    }

    private static void SwapGuidBytesToNetwork(byte[] b)
    {
        Array.Reverse(b, 0, 4); Array.Reverse(b, 4, 2); Array.Reverse(b, 6, 2);
    }

    private static void SwapGuidBytesFromNetwork(byte[] b)
    {
        Array.Reverse(b, 0, 4); Array.Reverse(b, 4, 2); Array.Reverse(b, 6, 2);
    }

    private static string ReplaceAll(string input, Dictionary<string, string> map)
    {
        foreach (var (k, v) in map) input = input.Replace(k, v);
        return input;
    }

    private static IReadOnlyList<MinecraftVersion> FallbackVersions()
    {
        string[] ids =
        [
            "1.21.8", "1.21.7", "1.21.6", "1.21.5", "1.21.4", "1.21.3", "1.21.2", "1.21.1", "1.21",
            "1.20.6", "1.20.5", "1.20.4", "1.20.3", "1.20.2", "1.20.1", "1.20",
            "1.19.4", "1.19.3", "1.19.2", "1.19.1", "1.19", "1.18.2", "1.18.1", "1.18",
            "1.17.1", "1.17", "1.16.5", "1.16.4", "1.16.3", "1.16.2", "1.16.1", "1.16",
            "1.15.2", "1.15.1", "1.15", "1.14.4", "1.14.3", "1.14.2", "1.14.1", "1.14",
            "1.13.2", "1.13.1", "1.13", "1.12.2", "1.12.1", "1.12", "1.11.2", "1.11", "1.10.2", "1.9.4", "1.8.9", "1.7.10"
        ];
        return ids.Select((id, i) => new MinecraftVersion(id, "release", "", DateTimeOffset.Now.AddDays(-i))).ToList();
    }

    private sealed record LibraryArtifact(string Path, string Url, long? Size, string? Sha1);
}
