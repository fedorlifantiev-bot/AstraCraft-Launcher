using System.Diagnostics;
using AstraCraft.Models;

namespace AstraCraft.Services;

public sealed class BedrockService
{
    public string MojangDir => Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "Packages", "Microsoft.MinecraftUWP_8wekyb3d8bbwe", "LocalState", "games", "com.mojang");

    public bool IsInstalledLike => Directory.Exists(MojangDir);

    public void Launch()
    {
        if (!OperatingSystem.IsWindows()) throw new PlatformNotSupportedException("Bedrock launch is supported on Windows only.");
        Process.Start(new ProcessStartInfo { FileName = "minecraft://", UseShellExecute = true });
    }

    public void OpenFolder()
    {
        Directory.CreateDirectory(MojangDir);
        Process.Start(new ProcessStartInfo { FileName = MojangDir, UseShellExecute = true });
    }

    public IReadOnlyList<FileItem> Scan(string category)
    {
        var path = Path.Combine(MojangDir, category);
        Directory.CreateDirectory(path);
        return Directory.EnumerateFileSystemEntries(path)
            .Select(p => new FileItem(Path.GetFileName(p), p, File.Exists(p) ? new FileInfo(p).Length : 0, File.GetLastWriteTime(p)))
            .OrderBy(x => x.Name)
            .ToList();
    }

    public void Import(IEnumerable<string> files)
    {
        foreach (var f in files.Where(File.Exists))
            Process.Start(new ProcessStartInfo { FileName = f, UseShellExecute = true });
    }
}
