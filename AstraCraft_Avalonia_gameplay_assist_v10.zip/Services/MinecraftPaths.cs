namespace AstraCraft.Services;

public static class MinecraftPaths
{
    public static void EnsureBaseFolders(string minecraftDir)
    {
        Directory.CreateDirectory(minecraftDir);
        foreach (var name in new[] { "versions", "libraries", "assets", "mods", "shaderpacks", "resourcepacks", "saves", "logs" })
            Directory.CreateDirectory(Path.Combine(minecraftDir, name));
        Directory.CreateDirectory(Path.Combine(minecraftDir, "assets", "indexes"));
        Directory.CreateDirectory(Path.Combine(minecraftDir, "assets", "objects"));
    }
}
